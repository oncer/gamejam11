---------------------
| SUPER EXTINCTION! |
---------------------

Game entry for Global Game Jam 2011

Site: Austria Game Jam / Vienna
Participants:
  Bora Celen -- Design, Graphics
  Elias Pschernig -- Design, Programming
  Simon Parzer -- Design, Audio, Programming
  Peter Neubauer -- Design, Programming

Additional Content:
  Arjaan Auinger -- Background Music

Controls:
  Arrow Keys  -- move around
  Shift/Space -- shoot
  F1          -- resign level
  Esc         -- quit

Happy critters have invaded your planet. Their uncontrolled happiness is a threat to world peace! Kill them before they multiply and infest everything.

The enemies are not a direct threat to you, but they consume all the food. If you see a food item appear, collect it as soon as possible, or else you might starve to death.

You start out with a simple gun, but be patient and better weapons will appear for you to pick up and massacre the enemy hordes:
Level 3 and up - flame thrower
Level 6 and up - laser gun

Dead enemies explode and leave behind body parts. The bits are food to all the other enemies. An enemy needs to consume 3 food in order to split in two. The enemy is dangerous in numbers!

